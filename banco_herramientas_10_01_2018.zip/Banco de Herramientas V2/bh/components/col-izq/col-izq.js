function getColIzq(){
  return `
  <div class="logo-img">
    <img src="bh/img/chec.png" alt="CHEC">
  </div>
  <div class="lista-opciones">
    <a id="inicio">
      <img src="bh/img/Inicio-01.png" alt="">
      <span>Inicio</span>
    </a>
    <a id="generalidades">
      <img src="bh/img/GeneralidadesGris-01.png" alt="">
      <span>Generalidades</span>     
    </a>
    <a id="criterios">
    <img src="bh/img/CriteriosConceptualesGris-01.png" alt="">
    <span>Criterios conceptuales</span>
    </a>
    <a id="herramientas">
      <img src="bh/img/HerramientasDidácticasGris-01.png" alt="">
      <span>Herramientas didácticas</span>
    </a>
    <a id="glosario">
      <img src="bh/img/GlosarioGris-01.png" alt="">
      <span>Glosario</span>
    </a>
    <a id="recurso">
      <img src="bh/img/GlosarioGris-01.png" alt="">
      <span>Recursos</span>
    </a>
  </div>
  <div class="um-img">
    <img src="bh/img/um2.png" alt="Universidad de Manizales">
  </div>
  `;
}
